package Tests;

import Models.Matakuliah;

public class MatakuliahTest {
    
}
